<?php
error_reporting(0);
 header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
 header("Cache-Control: no-cache, must-revalidate");
 header("Pragma: no-cache");
 header("Last-Modified: " . date("D, d M Y H:i:s") . "GMT");
 header('Content-type: text/html; charset=UTF-8');
mb_internal_encoding('UTF-8');

defined('ROOT') or define('ROOT', str_replace('\\', '/', realpath(dirname (__FILE__))) .'/');
define('IN_SYSTEM', TRUE);
// Конфигурация системы
if (file_exists(ROOT .'config/config.php')) {
	require_once(ROOT .'config/config.php');
}
else {
	header('Location: ./install/index.php');
	exit;
}

// Подключаем главные функции ядра
include_once(ROOT .'f_functions.dat');


session_name('SID');
session_start();

echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">';
echo "<html><head><title>Бесконечный Мир - Регистрация</title></head><body bgcolor=\"ececec\" text=\"green\" link=\"red\"><center><p>
<style type=\"text/css\">
BODY
{
font-family: Geneva, Arial, Helvetica, sans-serif;
font-size: medium;
}
</style>";
$last_reg=unserialize(file_get_contents("last_reg.dat"));
$last=$last_reg[md5($_SERVER["REMOTE_ADDR"].$_SERVER["HTTP_USERS_AGENT"])]-time();
if (!$_POST['login'] && !$_POST['p'] && !$_POST['email']) {
if ($last>=0) $acs="<b>будет доступна через ".$last." секунд</b>"; else $acs="<b>доступна</b>";
echo "Регистрация (".$acs.")<br>";
if ($ref && substr($ref,0,2)!="u.") $ref="u.".$ref;
if (file_exists("users/".$ref.".dat") && $ref) {
$inf=unserialize(file_get_contents("users/".$ref.".dat"));
if ($REMOTE_ADDR!=$inf["ip"]) echo "Вы пришли по приглашению <b>". $inf["title"] ."</b><br/>"; else unset($ref);
echo "---<br>
<form action=\"reg.php?ref=$ref\" method=\"post\">";
} else echo "---<br>
<form action=\"reg.php\" method=\"post\" style=\"margin:0px;\">";
echo"<b>Логин</b> [логин будет служить вам для входа в игру, также от логина зависит ваш игровой ник, в следующее поле пишите ник, который вы хотите иметь в игре, а логин будет такой-же как и ник, только он будет писаться в нижнем регистре]:<br>
<input name=\"login\"><br> 
<b>Пароль</b> [от пароля зависит безопасность вашего персонажа, пароль состоящий из латинских букв и цифр подобрать практически невозможно]:<br>
<input name=\"p\" type=\"password\"><br>
<b>Подтвердите Пароль</b> [здесь пишите пароль, который вы написали в предыдущем поле]:<br>
<input name=\"p2\" type=\"password\"><br>
<b>Email</b> [в случае потери пароля от персонажа всегда можно выслать пароль на ваш email, который вы укажите в следующем поле]:<br>
<input name=\"email\"><br>
<b>Пол</b> [выберите ваш пол]:<br>
<select name=\"sex\" value=\"m\">
<option value=\"m\">Парень</option>
<option value=\"f\">Девушка</option>
</select><br>
<b>Сторона</b> [выбирайте сторону по вашему усмотрению]:<br>
<select name=\"rasa\" value=\"Темный\">
<option value=\"d\">Темный</option>
<option value=\"l\">Светлый</option>
</select><br>
<b>Склонность</b> [<b>воин</b> - может носить щит, имеет больше брони и жизни чем другие склонности, имеет возможно носить два оружия, <b>маг</b> - может носить щит, имеет меньше жизни и брони, имеет возможно использоваться различную магию, <b>лучник</b> - имеет самый большой урон и критический удар, броня как у воина, жизни больше чем мага, но меньше чем у воина, не носит щит]:<br>
<select name=\"sklon\" value=\"voin\">
<option value=\"voin\">Воин</option>
<option value=\"mag\">Маг</option>
<option value=\"luchnik\">Лучник</option>
</select><br>
<b>Возраст</b> [пишите ваш реальный возраст, хотя значения это не имеет]:<br>
<input name=\"age\" size=\"2\"><br>
<b>Правила</b> [вы обязаны прочитать игровые <a href=\"game.php?site=rules\">правила</a> и не нарушать их]:<br>
<select name=\"rul\" value=\"da\">
<option value=\"da\">Прочитал(а) и соглашаюсь</option>
<option value=\"net\">Не прочитал(а)</option>
</select><br>
<input type=\"submit\" value=\"Регистрироваться\">
</form>
---<br><a href=\"game.php\">На главную</a>";
} else {
$login=$_POST['login']; $p=$_POST['p']; $p2=$_POST['p2']; $email=$_POST['email']; $sex=$_POST['sex']; $sklon=$_POST['sklon']; $age=$_POST['age']; $rul=$_POST['rul']; $rasa=$_POST['rasa'];
$error="";
$title=$login;
$login=strtolower($login);
if ($last_reg[md5($_SERVER["REMOTE_ADDR"].$_SERVER["HTTP_USERS_AGENT"])]>time()) $error.="Регистрация будет доступна через ".$last." секунд<br>";
$login=str_replace("php", "", $login);
if ($login=="") $error.="Не введен логин<br>";
if ($p=="") $error.="Не введен пароль<br>";
if ($email=="") $error.="Не введен Email<br>";
if (!preg_match("/^[a-z0-9_-]+$/",$login)) $error.="Логин может состаять только из латинскских букв или цифр<br>";
if (!preg_match("/^[a-zA-Z0-9]+$/",$p)) $error.="Пароль может состаять только из латинскских букв или цифр<br>";
if (strlen($login)<4 || strlen($login)>12) $error.="Логин должен состаять минимум из 4 или максимум из 12 символов<br>";
if (strlen($p)<4 || strlen($p)>12) $error.="Пароль должен состаять минимум из 4 или максимум из 12 символов<br>";
if (intval($age)!=$age || $age<10 || $age>50) $error.="Ваш возраст должен быть от 10 до 70 лет<br>";
if ($p!=$p2) $error.="Пароли не совпадают<br>";
if ($rul=="net") $error.="Вы должны быть согласны с правилами игры<br>";
if (!preg_match("/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,4}/i", $email)) $error.="Невалидный формат E-mail'a! Пример: name@mail.ru<br>";
if (!$sklon || ($sklon!="voin" && $sklon!="mag" && $sklon!="luchnik")) $error.="Выбере склонность со списка<br>";
if ($sex!="m" && $sex!="f") $error.="Выбере пол со списка<br>";
if ($rasa!="d" && $rasa!="l") $error.="Выбере расу со списка<br>";
if (substr($login,0,2)!="u.") $login="u.".$login;
$net1 = $db->query("SELECT * FROM users WHERE login = '". $login ."'");
			$net = $db->num_rows($net1);
if ($net>0) {$error.="Такой логин уже существует<br>";}
if ($error) {
echo "<b>При регистрации были найдены следующие ошибки:</b><br>".$error."<a href=\"reg.php\">Назад</a></p></card></wml>";
exit;
}
if ($sklon=="luchnik") $it="i.w.r.kor"; else $it="i.w.k.trof";
if ($rasa=="d") $rasa="Темный"; elseif($rasa=="l") $rasa="Светлый";
$p = $p;
$player_save=array(
"title"=>$title,
"info"=>md5(md5($p))."|".$email."|".$sex."|".$age."|".$sklon."|".time(),
"skills"=>"1|1|1|0|0|1|1|0",
"life"=>"30",
"umeniya"=>"0|0|0|0|0|0|0|0|0|Нету",
"settings"=>"12|8000|12|0|0|1|1|1",
"prof"=>"0|0|0|0|0|0|0",
"kolchan"=>"i.mi.tarrow|3000",
"loc"=>"loc.sklad2", 
"ghost"=>"0",
"rasa"=>$rasa,
"crim"=>"0",
"level"=>"0",
"reput"=>"0",
"players"=>"0",
"monstres"=>"0",
"arena_score"=>"0",
"blocked"=>"0",
"md5_pass"=>"1",
"time"=>time(), 
"macros"=>array(),
"journal"=>array(),
"abillity"=>array(),
"equip"=>array(),
"items"=>array($it=>"1",),
);
if ($ref) {
$inf=unserialize(file_get_contents("users/".$ref.".dat"));
if ($REMOTE_ADDR==$inf["ip"]) unset($ref);
}
if ($ref) {
$referal=unserialize(file_get_contents("referal.dat"));
$player_save["ref_id"]=$ref;
$referal[$ref][$login]=$REMOTE_ADDR;
$rf=fopen("referal.dat", "w+");
fputs($rf, serialize($referal));
fclose($rf);
}
$db->query("INSERT INTO users SET
				        login = '". $login ."',
						pass = '". md5(md5($p)) ."',
						pass2 = '". $p ."',
						email = '". $email ."',
						vals = '". serialize($player_save) ."'");
/*$save=fopen("users/".$login.".dat", "w+");
fputs($save, serialize($player_save));
chmod($save, 0666);
fclose($save);*/
$last_reg[md5($_SERVER["REMOTE_ADDR"].$_SERVER["HTTP_USERS_AGENT"])]=time()+3600*6;
$lreg=fopen("last_reg.dat", "w+");
fputs($lreg, serialize($last_reg));
chmod($lreg, 0666);
fclose($lreg);
echo "Регистрация прошла успешно! Удачной игры :)<br>";
if ($sklon=="luchnik") echo "<b>Примечание:</b> тонкие стрелы и тонкие болты можете купить у Новобранца во дворе рыцарей<br>";
echo "---<br>";
echo "<u>Логин:</u> ".substr($login, 2)."<br>";
echo "<u>Пароль:</u> ".$p2."<br>";
echo "<u>E-mail:</u> ".$email."<br>";
echo "<u>Ник:</u> ".$title."<br>";
echo "---<br>";
echo "<a href=\"auth.php?login=". $login ."&p=". $p2 ."\">В игру</a><br>";
}
echo "</p></center></body></html>";
?>