<?php
/*Гладиатор*/
if (!$arena) {
	$stmp="Все заявки на данный момент<br/>---<br/>";
	$arr=array();
$dh = opendir("arena"); 
while (($fname = readdir($dh))!== false) if ($fname!="." && $fname!=".." && $fname!="go" && $fname!=".htaccess" && $fname!="arena.dat" && substr($fname,strlen($fname)-5)!="-bank") {
$arr[$fname]=count($tmp["m"])+1;
}
closedir($dh);
$stmp="Заявки (".count($arr).")<br/>---<br/>";
if (count($arr)==0) $stmp.="Заявок не найдено<br/>";
arsort($arr);
if (!$start) $start=0;
$keys=array_keys($arr);
for($i=$start;$i<$start+$count_show && $i<count($keys);$i++) {
$arenaInfo=unserialize(file_get_contents("arena/". $keys[$i]));
if ($arenaInfo["time"] == 60) {$timeb = "1 минута";}
if ($arenaInfo["time"] == 180) {$timeb = "3 минуты";}
if ($arenaInfo["time"] == 300) {$timeb = "5 минут";}
if ($keys[$i] == $login) {
	$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&arena=del&id1=". $keys[$i] ."\">Удалить свою заявку</a> [". $arenaInfo["repa"] ." репутации время ". $timeb ."]<br/>";
	} else {
		$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&arena=ok&id1=". $keys[$i] ."\">". $arenaInfo["login"] ."</a> [". $arenaInfo["repa"] ." репутации время ". $timeb ."]<br/>";
	}
}
$ind=count($keys);
if ($ind>$count_show) {
$stmp.="---<br/>";
$count=ceil($ind/$count_show);
for ($j=0;$j<$count;$j++){
if ((ceil($start/$count_show)+1)==($j+1)) $stmp.=($j+1)." "; else $stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&start=".($j*$count_show)."\">".($j+1)."</a> ";
}
$stmp.="<br/>";
}
}
if ($arena=="del") {
	if (!file_exists("arena/". $id1)) {
		msg("Нет такой заявки!");
	}
	unlink("arena/". $id1);
	msg("Заявка успешно удалена!");
}
if ($arena=="ok") {
	if (file_exists("arena/arena.dat")) {msg("В данный момент уже идет бой. Дождитесь его окончания.");}
	$boy=unserialize(file_get_contents("arena/".$id1));
	if ($player["reput"]<$boy["repa"]) {
		$repaut = $boy["repa"] - $player["reput"];
		msg("У вас не достаточно репутации. Не хватает: ". $repaut ." единиц репутации");
		}
	$boyChek=array(
"login1"=>$id1,
"login2"=>$login,
"repa"=>$boy["repa"],
"time"=>time()+$boy["time"],
);
$f=fopen("arena/arena.dat","w+");
fputs($f, serialize($boyChek));
fclose($f);
$f1=fopen("arena/go/". $login,"w+");
fputs($f1, serialize($boyChek));
fclose($f1);
$f2=fopen("arena/go/". $id1,"w+");
fputs($f2, serialize($boyChek));
fclose($f2);
unlink("arena/". $id1);
add_notice($id1,"<u>Ваша заявка принята! Проходите на арену.</u>");
add_notice($login,"<u>Вы приняли заявку! Проходите на арену.</u>");
$stmp="Заявка принята! Проходите на арену.";
}
msg($stmp);

?>