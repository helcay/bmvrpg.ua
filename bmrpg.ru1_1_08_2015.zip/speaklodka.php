<?php
$stmp="Список островов<br/>---<br/>";
if (!$to) {
if ($player["loc"]=="loc.lodka") {
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=1\">Злой Остров (Evil Island)</a> (2000 золота)<br/>";
/*$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=2\">Окара</a> (1000 репутации или камень Окары)<br/>";
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=3\">Немора</a> (1000 репутации или камень Неморы)<br/>";
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=4\">Ущелье Изгнанников</a> (1000 репутации или камень Ущелья Изгнанников)<br/>";
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=5\">Снежные Горы</a> (1000 репутации или камень Снежных Гор)<br/>";
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=6\">Мидгард</a> (250 золота)<br/>";
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=9\">Болото Страданий</a> (1200 золота)<br/>";*/
} elseif ($player["loc"]=="loc.os_78") {
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=4\">К основному городу</a> (2000 золота)<br/>";
}/* elseif ($player["loc"]=="loc.vk_71") {
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=8\">Мидгард</a> (1000 золота)<br/>";
} elseif ($player["loc"]=="loc.bs_0") {
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=10\">Основной город</a> (750 золота)<br/>";
} elseif ($player["loc"]=="loc.piram0") {
$stmp.="<a href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&to=11\">Пирамида</a> (10000 золота)<br/>";
}*/
$stmp.="---<br/><a href=\"$PHP_SELF?sid=$sid\">В игру</a>";
msg($stmp);
} elseif ($to>=1 && $to<=10) {
if ($to==1) {
if ($player['items']['i.mi.gold']<2000) msg("У вас не хватает золота для прохода");
$player["items"]["i.mi.gold"]-=2000; 
$loc="loc.os_78";
} elseif ($to==4) {
if ($player['items']['i.mi.gold']<2000) msg("У вас не хватает золота для прохода");
$player["items"]["i.mi.gold"]-=2000; 
$loc="loc.lodka";
}
if ($loc) {
$game["loc"][$loc][$login]=$game["loc"][$player["loc"]][$login];
unset($game["loc"][$player["loc"]][$login]);
unset($player);
$player=&$game["loc"][$loc][$login];
$player["loc"]=$loc;
$game["players"][$login]=$loc;
$locations[$loc]=file_get_contents("loc/".$loc.".dat");
addjournal($login, "Желаю удачи на острове!");
}
}
?>