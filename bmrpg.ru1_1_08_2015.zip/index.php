<?php
header("Location: game.php");
?>