<?php

$arr_item=array(
"i.a.boots.predk", "i.a.head.chcherep", "i.a.leg.kost", "i.a.sh.krov", "i.plawq.fenix", "i.plawq.sled",);
$rand=array_rand($arr_item);
$player["items"][$arr_item[$rand]]++;
$player["items"]["i.box.prok"]-=1;
if ($player["items"]["i.box.prok"]<1) unset($player["items"]["i.box.prok"]);
$item=explode("|", file_get_contents("items/".$arr_item[$rand]));
add_notice($login,"<u>Вы получили 1 шт. ".$item[0]." из Проклятого ящика</u>");
addjournal($login, "Вы получили 1 шт. ".$item[0]." из Проклятого ящика");

?>