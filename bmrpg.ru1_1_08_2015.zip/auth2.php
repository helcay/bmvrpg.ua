<?php
### Create By Данте. ICQ: 81107977. 
### Распространению не подлежит!
Error_Reporting(E_ALL & ~ E_NOTICE);
 header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
 header("Cache-Control: no-cache, must-revalidate");
 header("Pragma: no-cache");
 header("Last-Modified: " . date("D, d M Y H:i:s") . "GMT");
 header('Content-type: text/html; charset=UTF-8');
mb_internal_encoding('UTF-8');
@ ini_set('arg_separator.output', '&amp;');
@ ini_set('session.use_trans_sid', '0');
if (get_magic_quotes_gpc()) {
    // Удаляем слэши, если открыт magic_quotes_gpc
    $in = array(& $_GET, & $_POST, & $_COOKIE);
    while (list($k, $v) = each($in)) {
        foreach ($v as $key => $val) {
            if (!is_array($val)) {
                $in[$k][$key] = stripslashes($val);
                continue;
            }
            $in[] = & $in[$k][$key];
        }
    }
    unset ($in);
}
session_name('SID');
session_start();

$PHP_SELF='game.php';
$admin = "u.dante";
$admin1 = "u.bupyc";
$game_file = "game.dat";
$game="";
$max = 150;
$sid = "time_ses=".time();

require "f_functions.dat";

if (isset($_POST["login"]) && isset($_POST["p"])) {
	$login = txt($_POST["login"]);
	$p = txt($_POST["p"]);
	
} else {
	$login = txt($_GET["login"]);
	$p = txt($_GET["p"]);
	
} 

if (substr($login,0,2)!='u.') $login='u.'.$login;

if (file_exists("flag_update") && $login!=$admin && $login!=$admin1) require "f_update.dat";

$p1 = $p;

if (!$login && !$p) {print "<center>Вы не ввели логин и пароль!!!<br/><a href=\"/\">На главную</a></center>";exit;}
if (!$login) {print "<center>Вы не ввели логин!!!<br/><a href=\"/\">На главную</a></center>";exit;}
if (!$p) {print "<center>Вы не ввели пароль!!!<br/><a href=\"/\">На главную</a></center>";exit;}

if (file_exists($game_file)) {
$file_save = fopen($game_file,'r+');
if (flock($file_save,2)) {
rewind($file_save);
while (!feof ($file_save)) $game.= fgets($file_save, filesize($game_file));
$game = unserialize($game);
}
} else {$file_save = fopen($game_file,'w+'); if ($file_save && flock($file_save,2))  require 'f_blank.dat'; else {
	$file_save=''; print'<center>Ошибка создания '. $game_file .'<br/><a href=\"/\">На главную</a></center>';exit;}}
	
	if (!$game["players"][$_SESSION["logins"]] && isset($_COOKIE['login'])) {
		unset($_SESSION['login']);
        unset($_SESSION['pass']);
        setcookie('login', '');
        setcookie('pass', '');
        session_destroy();
	}
	
if (isset($_SESSION["logins"]) && $_SESSION["logins"] != $login) {
	
	$usrDataSes=unserialize(file_get_contents("users/". $_SESSION["logins"] .".dat"));
	
	print "<center>Извините, но до окончания сессии ". $usrDataSes["title"] ." вы не можете войти в игру с данного браузера.
<br/><a href=\"/\">На главную</a></center>";exit;
}

if (file_exists("users/".$login.".dat")) {
if (!$game["players"][$login]) {$usrData=unserialize(file_get_contents("users/".$login.".dat"));} else {$usrData=$game["loc"][$game["players"][$login]][$login];}

if (isset($usrData["md5_pass"]) && $usrData["md5_pass"]==1) {$p = md5(md5($p));} else {$p = md5(md5($p));}

$info=explode("|",$usrData["info"]);
if ($info[0]!=$p) msg("<center>Неправильный пароль<br/><a href=\"/\">На главную</a></center>".$p);

if ($HTTP_USER_AGENT=="Opera") {
foreach (array_keys($game["players"]) as $i) {
$ip[$game["loc"][$game["players"][$i]][$i]["ip"]]++;
}
}
/*if ($ip[$REMOTE_ADDR]>=3 && !$game["players"][$login] && $login!=$admin) {$login=""; 
print "<center>Извините, но вы не можете зайти в игру в данный момент так как с этого айпи (".$REMOTE_ADDR.") адреса уже играет достаточное количество игроков
<br/><a href=\"/\">На главную</a></center>";exit;}*/
$loc=$usrData["loc"];
$game["loc"][$loc][$login]=$usrData;
if ($login!=$admin && count($game["players"])>=$max) {$login=""; 
print "<center>Извините, на сервере установлено ограничение не более ".$max." игроков онлайн, 
попробуйте войти позднее. Вы можете сохранить в своем телефоне закладку на эту страницу, чтобы не вводить каждый раз логин и пароль вручную.
<br/><a href=\"/\">На главную</a></center>";exit;}

if (!isset($game["players"][$login])) {
$game["players"][$login]=$loc;
$info=explode("|",$game["loc"][$loc][$login]["info"]);
if ($info[2]=="f") $titleM="появилась"; else $titleM="появился";
addjournalall($loc,$titleM." ".$game["loc"][$loc][$login]["title"],$login);
if ($game["loc"][$loc][$login]["crim"]) {$game["loc"][$loc][$login]["time_crim"]=time()+$game["loc"][$loc][$login]["time_crim"]-$game["loc"][$loc][$login]["time"];}
if ($game["loc"][$loc][$login]["time_char_m"]) $game["loc"][$loc][$login]["time_char_m"]=time()+$game["loc"][$loc][$login]["time_char_m"]-$game["loc"][$loc][$login]["time"];
if ($game["loc"][$loc][$login]["time_char_b"]) $game["loc"][$loc][$login]["time_char_b"]=time()+$game["loc"][$loc][$login]["time_char_b"]-$game["loc"][$loc][$login]["time"];
if ($game["loc"][$loc][$login]["time_char_l"]) $game["loc"][$loc][$login]["time_char_l"]=time()+$game["loc"][$loc][$login]["time_char_l"]-$game["loc"][$loc][$login]["time"];
if ($game["loc"][$loc][$login]["time_char_mp"]) $game["loc"][$loc][$login]["time_char_mp"]=time()+$game["loc"][$loc][$login]["time_char_mp"]-$game["loc"][$loc][$login]["time"];
if ($game["loc"][$loc][$login]["time_char_u"]) $game["loc"][$loc][$login]["time_char_u"]=time()+$game["loc"][$loc][$login]["time_char_u"]-$game["loc"][$loc][$login]["time"];
$game["loc"][$loc][$login]["time_regenerate"]=time();
$game["loc"][$loc][$login]["time"]=time();
if (!$game["loc"][$loc][$login]["umeniya"]) $game["loc"][$loc][$login]["umeniya"]="0|0|0|0|0|0|0|0|0|Нету";
$skills=explode("|",$game["loc"][$loc][$login]["skills"]);
if (count($skills)>15) $game["loc"][$loc][$login]["skills"]="1|1|1|".$skills[3]."|".round($game["loc"][$loc][$login]["level"]/3)."|1|1|0";
if (!$game["loc"][$loc][$login]["prof"]) $game["loc"][$loc][$login]["prof"]="0|0|0|0|0|0|0";
}

unset($game["loc"][$loc][$login]["killed"]);
unset($game["loc"][$loc][$login]["q"]);
unset($game["loc"][$loc][$login]["tonline"]);
unset($game["loc"][$loc][$login]["blocked"]);
unset($game["loc"][$loc][$login]["ng"]);
unset($game["loc"][$loc][$login]["admin"]);
unset($game["loc"][$loc][$login]["refresh"]);
unset($game["loc"][$loc][$login]["kv"]);
unset($game["loc"][$loc][$login]["magic"]);
unset($game["loc"][$loc][$login]["notalk"]);
unset($game["loc"][$loc][$login]["msg"]);


                        setcookie("login", $login, time() + 3600 * 24 * 365);
                        setcookie("pass", $p, time() + 3600 * 24 * 365);
$_SESSION["logins"] = $login;
$_SESSION["pass"] = $p;

$date=file_get_contents("news/".count(glob("news/*")).".dat");
$date=explode("|", $date);
$online=count($game["players"]);
$on=$online;
if (strlen($online)>1) $on=substr($online,strlen($online)-1,1);
if ($on==0 || ($on>=5 && $on<=9)) $word="ов"; elseif ($on>=2 && $on<=4) $word="а";
$stmp="<b>Добро пожаловать в Бесконечный Мир!</b><br/>
---<br/>
<u>В игре:</u>".$online." игрок".$word."<br/>
---<br/>
<a href=\"$PHP_SELF?site=news\">Новости игры</a> (".$date[1].")<br/>
<a href=\"$PHP_SELF?sid=$sid&menu=1\">Меню</a><br/>
<a href=\"$PHP_SELF?sid=$sid&menu=1\">Помощь по игре</a><br/>
Для автологина сохраните закладку на эту <a href=\"auth.php?login=". $login ."&p=". $p1 ."\">страницу</a><br/>
<img src = 'vk_1.png'/> <a href=\"http://vk.com/onlainers_ru\"  target=\"_blank\">Мы в Вконтакте</a><br/>
<a href=\"$PHP_SELF?sid=$sid\">В игру</a><br/>
---<br/>
<a href=\"/\">На главную</a><br/>";
msg($stmp);
} else msg ("Такой логин не существует, вам надо зарегистрироваться","Ошибка",0,'none');

?>