<?php

foreach ($_GET as $get_key => $get_value) $$get_key = $get_value;
foreach ($_POST as $post_key => $post_value) $$post_key = $post_value;
$HTTP_USER_AGENT = getenv("HTTP_USER_AGENT");
$HTTP_USER_AGENT = strtok($HTTP_USER_AGENT, "/");
$REMOTE_ADDR=$_SERVER["REMOTE_ADDR"];
$HTTP_X_FORWARDED_FOR = getenv("HTTP_X_FORWARDED_FOR");
$HTTP_X_FORWARDED_FOR = strtok($HTTP_X_FORWARDED_FOR, ",");
if ($HTTP_X_FORWARDED_FOR && $_SERVER["REMOTE_ADDR"]!=$HTTP_X_FORWARDED_FOR) $REMOTE_ADDR=$HTTP_X_FORWARDED_FOR;
if (!$HTTP_USER_AGENT) die();

defined('ROOT') or define('ROOT', str_replace('\\', '/', realpath(dirname (__FILE__))) .'/');
define('IN_SYSTEM', TRUE);

// Конфигурация системы
if (file_exists(ROOT .'config/config.php')) {
	require_once(ROOT .'config/config.php');
}
else {
	header('Location: ./install/index.php');
	exit;
}

$login = $_COOKIE['login'];
$p = $_COOKIE["pass"];
$_SESSION["logins"] = $_COOKIE['login'];
$_SESSION["pass"] = $_COOKIE["pass"];

// Подключаем главные функции ядра
include_once(ROOT .'f_functions.dat');



#if (file_exists("flag_debug")) {$debug=1;} else {$debug="";}

$PHP_SELF='game.php';
$admin = "u.dante";
$admin1 = "u.bupyc";
$admin2 = "u.morok";
/*$fuck = "";
$dima = $fuck;
$dima = "";
$fuck = $dima; 
$dima = "u.dante";
*/
$game_file = "game.dat";
$game_title = "Бесконечный Мир";
$time_logout = 10*60;
$time_objects_destroy = 8*60;
$time_crim = 10*60;
$time_regenerate = 20;
$max = 150;
$current_time=time()+24*3600;
$count_show=20;
$max_lvl=700;
$page_main="";
$game="";
$site=preg_replace('/\W/',"",$site);



#if (!isset($_GET["time_ses"])) {session_destroy();}

if (file_exists("flag_update") && $login!=$admin && $login!=$admin1 && $login!=$admin2) require "f_update.dat";


	header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0, max-age=86400');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Pragma: no-cache');
header("Content-type: text/vnd.wap.wml; charset=UTF-8");
// Кодировка UTF-8 
setlocale(LC_ALL, 'Russian_Russia.65001');


/*
header("Content-type: text/html");
echo '<?xml version="1.0" encoding="utf-8"?>';
echo '<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>';

header("Content-type:text/vnd.wap.wml;charset=UTF-8");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
echo "<?xml version='1.0' encoding='utf-8'?>";
echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">";
setlocale(LC_CTYPE, 'ru_RU.utf-8');
*/

#require "f_functions.dat";

$login=str_replace('$','',$login);

if (!$_SERVER["QUERY_STRING"]) $site="main";
/*if (!$login) $login=$sid; else {if (mb_substr($login,0,2)!='u.') $login='u.'.$login; $sid=$login;}

if (file_exists("users/".$login.".dat")) {
	$usrDataD=unserialize(file_get_contents("users/".$login.".dat"));
	$info=explode("|",$usrDataD["info"]);
if ($info[0] == md5(md5($p))) {$sid=$login."&p=".md5(md5($p));} else {$sid=$login."&p=".$p;}
} else {$sid=$login."&p=".$p;}
#if ($p != md5(md5($p))) {$p = md5(md5($p));} else { print "ПШЕЛ А ХУЙ НЕЛЮДЬ!!!"; exit;}
#$sid=$login."&p=".$p;
*/
#$sid = "time_ses=".time();
if ($sid) $sid.="&".rand(1000,9999);

if (file_exists($game_file)) {
$file_save = fopen($game_file,'r+');
if (flock($file_save,2)) {
rewind($file_save);
while (!feof ($file_save)) $game.= fgets($file_save, filesize($game_file));
$game = unserialize($game);
}
} else {$file_save = fopen($game_file,'w+'); if ($file_save && flock($file_save,2))  require 'f_blank.dat'; else {$file_save=''; msg('Ошибка создания '.$game_file);}}

if ($site && file_exists("f_site_".$site.".dat")) require "f_site_".$site.".dat"; elseif ($site && !file_exists("f_site_".$site.".dat")) require "f_site_error.dat";




if (!$game["loc"][$game["players"][$login]][$login]) msg("<b>Этот персонаж вне игры</b><br/><a href=\"$PHP_SELF\">На главную</a>","Ошибка",0,'none');
$info_u = $db->get_one("SELECT pass FROM users WHERE login = '". $login ."'");
if ($info_u!=md5(md5($p))){ msg("Неверный пароль<br/><a href=\"$PHP_SELF\">На главную</a>","Ошибка",0,'none');}


$player["time"]=time();
$locations[$player["loc"]]=file_get_contents("loc/".$player["loc"].".dat");

if ($drop || $transfer || $list=="prof") {
if ($player["last_url"]==md5($_SERVER["QUERY_STRING"])) msg("Запрещено выполнять не последовательные действия.");
$player["last_url"]=md5($_SERVER["QUERY_STRING"]);
}

$set=explode("|", $player["settings"]);
if ($set[0]>=5) $count_show=$set[0]; else $count_show=5;
$menu_on=$set[4];
$refresh_on=$set[5];
$heal_b=$set[9];

//////CASTLE
$catt=file_get_contents("castle_attack.dat");
if ($catt+1800<$current_time) {
$f=fopen("castle_attack.dat","w+"); fputs($f,$current_time+7200); fclose($f);
}
/////

calcparam($login);
if ($player["npc_speed"] && !$player["boev"]) unset($player["npc_speed"]);
if ($player["player_speed"] && !$player["boev"]) unset($player["player_speed"]);

ai();
if ($contact) require "f_msg.dat";
if ($player["trade"]) require "f_obmen2.dat";
if ($macros) require "f_macros.dat";
if ($chat) require "f_chat.dat";
if ($forum) require "f_forum.dat";
if ($adm) require "f_admin.dat";
if ($speak) require "f_speak.dat";
if ($book) require "f_book.dat";
if ($_POST['say']) require "f_say.dat";
if ($notice) require "f_notice.dat";
if ($menu) require "f_menu.dat";
if ($ignor) require "f_ignor.dat";
if ($mod) require "f_mod.dat";
if ($sms) require "f_sms.dat";
if ($group) require "f_group.dat";
if ($invite) require "f_invite.dat";
if ($tp) require "f_tp.dat";
if ($faq) require "f_faq.dat";
if ($nastr) require "f_nastr.dat";
if ($obmen) require "f_obmen.dat";
if ($gild && $player["gildija"]) require "f_gild.dat";
if ($c_quest) require "f_c_quest.dat";
if ($stat) require "f_stat.dat";
if ($_GET["attack"]) require "f_attack.dat";
if ($transfer) require "f_transfer.dat";
if ($take) require "f_take.dat";
if ($drop) require "f_drop.dat";
if ($use) require "f_use.dat";
if ($foto) require "f_foto.dat";
if ($list && file_exists("f_list".$list.".dat")) require "f_list".$list.".dat"; elseif ($list && !file_exists("f_list".$list.".dat")) msg("Станицы не существует");
if ($_POST["lookTo"]) {
if (mb_substr($_POST["lookTo"],0,2)=='i.') require "f_lookitem.dat";
if (mb_substr($_POST["lookTo"],0,2)=='u.') require "f_lookuser.dat";
if (mb_substr($_POST["lookTo"],0,2)=='n.')  require "f_looknpc.dat";
}
if ($go) require "f_go.dat";

$mmg="";
$msgInfo=unserialize(file_get_contents("msg/".$login.".dat"));
$arrMsg=array_keys($msgInfo);
foreach($arrMsg as $i) if ($game["players"][$i] && $i!="trade") {
if ($msgInfo[$i]) $ct++;
if ($i=="trade") $title="<b>Камень Торговли</b>"; else $title=$game["loc"][$game["players"][$i]][$i]["title"];
if ($msgInfo[$i] && $title) if ($ct>=2) $mmg.=", <a href=\"$PHP_SELF?sid=$sid&contact=read&id=$i\">".$title."</a>"; else $mmg.="<a href=\"$PHP_SELF?sid=$sid&contact=read&id=$i\">".$title."</a>";
}
if ($ct>=1) $page_main.= "<p>Контакты: ".$mmg."<br/>---<br/>"; else $page_main.="<p>";
$info=explode("|",$player["info"]);
if (!$player["md5_pass"]) {$page_main.= "<i><b>Срочно смените пароль!</b></i><br/>";}
$min_poison=(round(($player["poison"]-time())/60));
if ($min_poison<=0) unset($player["poison"]);
if ($player["poison"] && ($player["poison"]-time())>60) $page_main.= "<b><i>вы отравлены магией (".$min_poison." м.)</i></b><br/>"; elseif ($player["poison"]) $page_main.= "<b>вы отравлены магией (".($player["poison"]-time())." сек.)</b><br/>"; 
if ($player["ghost"]) $page_main.= "<i><b>вы призрак</b></i><br/>";
$min =(round(($player["time_crim"]-time())/60));
if ($player["crim"] && ($player["time_crim"]-time())>60) $page_main.= "<b><i>вы преступник (".$min." м.)</i></b><br/>"; elseif ($player["crim"]) $page_main.= "<b><i>вы преступник (".($player["time_crim"]-time())." сек.)</i></b><br/>"; 
$proc=round(100*$player["life"]/$player["life_max"]);
if ($HTTP_USER_AGENT=="Opera") {
if ($proc>=75) $page_main.="<font color=\"red\"></font><font color=\"red\"><u><img src=\"life.jpg\"/> <b>Жизнь</b></u> <font color=\"black\">[</font>".$player["life"]."<font color=\"black\">/</font>".$player["life_max"]."<font color=\"black\">]</font></font>";
if ($proc<75 && $proc>=40) $page_main.="<font color=\"red\"><u><img src=\"life.jpg\"/> Жизнь</u> <font color=\"black\">[</font><font color=\"orange\">".$player["life"]."</font><font color=\"black\">/</font>".$player["life_max"]."<font color=\"black\">]</font></font>";
if ($proc<40) $page_main.="<font color=\"red\"><u><img src=\"life.jpg\"/> Жизнь</u>  <font color=\"black\">[</font><font color=\"ddb30b\">".$player["life"]."</font><font color=\"black\">/</font>".$player["life_max"]."<font color=\"black\">]</font></font>";
} else $page_main.="<u><img src=\"life.jpg\"/> Жизнь</u> [<b>".$player["life"]."/".$player["life_max"]."</b>]";
if ($player["boev"]) $page_main.=" *";
if ($info[4]=='mag') $page_main.="<br/><u><img src=\"mana.jpg\"/> <b>Мана</b></u> [<b>".$player["mana"]."/".$player["mana_max"]."</b>]";
$page_main.="<br/>----------------------------";
$ind=0;
if(!$start) $start=0;
if ($start>(count($game["loc"][$player["loc"]])-1)) $start=0;
if ($game["loc"][$player["loc"]]) foreach (array_keys($game["loc"][$player["loc"]]) as $i) if ($i!=$login) {
if (mb_substr($i,0,2)=="u." && $game["loc"][$player["loc"]][$i]["loc"]!=$game["players"][$i]) unset($game["loc"][$player["loc"]][$i]);
if (!$usrOn && mb_substr($i,0,2)=="u.") $usrOn=1;
if (!$npcOn && mb_substr($i,0,2)=="n.") $npcOn=1;
if (mb_substr($i,0,9)=="i.s.died.") {
$c_died=explode("|", $game["loc"][$player["loc"]][$i]);
if (!$c_died[4] && !$c_died[5]) unset($game["loc"][$player["loc"]][$i]);
}
if ($game["loc"][$player["loc"]][$i]) {
if ($ind>=($start) && $ind<$start+$count_show) {
if (mb_substr($i,0,2)=='i.') {
if (mb_substr($i,0,13)=="i.recallrune.") {
$location=explode(".", $i);
$loc=explode("|",file_get_contents("loc/".$location[2].".".$location[3].".dat"));
$itemm=explode("|", "руна ".$loc[0]."|1");
} else {
$open=file("items/".$i);
$itemm=explode("|",$open[0]);
}
$data=explode("|",$game["loc"][$player["loc"]][$i]);
if (mb_substr($i,0,2)=="i." && mb_substr($i,0,4)!="i.s.") $s_title="<a href=\"$PHP_SELF?sid=$sid&take=$i&num=".$data[0]."\">".$itemm[0]."</a> (".$data[0]." шт.)";
if (mb_substr($i,0,4)=="i.s.") $s_title="<a href=\"$PHP_SELF?sid=$sid&take=$i\">".str_replace("1","",$data[0])."</a>";
} else {
if ($game["loc"][$player["loc"]][$i]["life_max"]>0) $ltmp=round(100*$game["loc"][$player["loc"]][$i]["life"]/$game["loc"][$player["loc"]][$i]["life_max"]);
if ($ltmp<100) $pl_life.=" [".$ltmp."%]";
if ($game["loc"][$player["loc"]][$i]["ghost"]) $pers.="!";
if (mb_substr($i,0,2)=='u.' && $game["loc"][$player["loc"]][$i]["crim"]) $pers.="*";
if ($game["loc"][$player["loc"]][$i]["gildija"]) $str.="[".$game["loc"][$player["loc"]][$i]["gildija"]."]";
if ($game["loc"][$player["loc"]][$i]["rasa"]=="Темный") $pers.="-"; elseif ($game["loc"][$player["loc"]][$i]["rasa"]=="Светлый") $pers.="+"; 
$att=$game["loc"][$player["loc"]][$i]["attack"];
if ($game["loc"][$player["loc"]][$i]["title"]) $s_title=$game["loc"][$player["loc"]][$i]["title"];
if ($att && isset($game["loc"][$player["loc"]][$att]) && !$game["loc"][$player["loc"]][$att]["ghost"] && !$game["loc"][$player["loc"]][$i]["ghost"]) $st.="[атак. ".$game["loc"][$player["loc"]][$att]["title"]."]";
if ($str) {$kk.=$str; $str='';}
if ($pl_life) {$kk.=$pl_life; $pl_life='';}
if ($st) {$kk.=$st; $st='';}
}
if (mb_substr($i,0,2)=='i.') $page_main.= "<br/>".$s_title;
if (mb_substr($i,0,2)=='n.') $page_main.= "<br/><anchor>".$s_title." [".$game["loc"][$player["loc"]][$i]["npc_lvl"]."]<go href=\"#npc\"><setvar name=\"to\" value=\"".$i."\"/></go></anchor> ".$kk;
if (mb_substr($i,0,2)=='u.') $page_main.= "<br/>".$pers."<anchor>".$s_title."<go href=\"#user\"><setvar name=\"to\" value=\"".$i."\"/></go></anchor> ".$kk;
$kk='';
$pers='';
$s_title='';
}
$ind++;
}
$ln=1;
}
if ($ln) $page_main.="<br/>---";
if ($ind>$count_show) {
$page_main.="<br/>";
$count=ceil($ind/$count_show);
for ($j=0;$j<$count;$j++){
if ((ceil($start/$count_show)+1)==($j+1)) $page_main.=($j+1)." "; else $page_main.="<a href=\"$PHP_SELF?sid=$sid&start=".($j*$count_show)."\">".($j+1)."</a> ";
}
$page_main.="<br/>---";
}
$loc=explode("|",$locations[$player["loc"]]);
if (!$locations[$player["loc"]]) $loc=explode("|", "тупик|1|выход из тупика|loc.0");
for ($i=3;$i<count($loc);$i++) {
if (mb_substr($loc[$i],0,4)=='loc.') {
$page_main.= "<br/><a href=\"$PHP_SELF?sid=$sid&go=".$loc[$i]."\">".$loc[$i-1]."</a>";
if (count($game["loc"][$loc[$i]])>0) foreach(array_keys($game["loc"][$loc[$i]]) as $j) if ((mb_substr($j,0,2)=='u.') || mb_substr($j,0,2)=='n.') {if (count($game["loc"][$loc[$i]])<=2) $page_main.=" !"; elseif (count($game["loc"][$loc[$i]])<=5 && count($game["loc"][$loc[$i]])>2) $page_main.=" !!"; elseif (count($game["loc"][$loc[$i]])>5) $page_main.=" !!!"; break;}
}
}
$page_main.="<br/>---<br/>";
if ($refresh_on) $page_main.="<a href=\"$PHP_SELF?sid=$sid\"><img src=\"obnovit.jpg\"/><b> Обновить</b></a><br/>";
if (count($player["notice"])>=1) $page_main.="<a href=\"$PHP_SELF?sid=$sid&notice=1\"><img src=\"uvid.png\"/><b> Уведомления</b></a> - ".count($player["notice"])."<br/>";
if ($menu_on) $page_main.="<anchor> <b>Меню</b><go href=\"#menu\"></go></anchor><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&chat=msg\"><img src=\"chat.png\"/><b> Чат</b></a> - ".count(unserialize(file_get_contents("chat/1.dat")))."<br/>";
if (file_exists("chat/".$player["gildija"].".dat")) $page_main.="<a href=\"$PHP_SELF?sid=$sid&chat=msg&gc=1\"><img src=\"chat-gild.png\"/><b> Чат гильдии</b></a> - ".count(unserialize(file_get_contents("chat/".$player["gildija"].".dat")))."<br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&forum=1\"><b>Форум</b></a><br/>";
$page_main.="---<br/>";
$page_main.="<b>Europe/Moskov - [".date("H:i:s", $current_time)."]</b><br/>";

if ($login==$admin || $login==$admin1 || $login==$admin2) $page_main.="<br/><a href=\"$PHP_SELF?sid=$sid&adm=1\">Администраторская !</a>";
if ($player["mod"]) $page_main.="<br/><a href=\"$PHP_SELF?sid=$sid&mod=1\"><b>Модераторская !</b></a>";

if ($menu_on) {
$page_main.="</p></card><card id=\"menu\" title=\"Меню\"><p>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&list=inv\">Персонаж</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&list=items\">Рюкзак</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&speak=1\">Написать окружающим</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&contact=1\">Контакты</a><br/>";
if (isset($player["macros"]["last"]) && mb_substr($player["macros"]["last"],0,2)=="i.") {
if (!$player["macros"]["last_to"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=".$player["macros"]["last"]."\">Повторить</a><br/>"; else $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=".$player["macros"]["last"]."&to=".$player["macros"]["last_to"]."\">Послед. исп.</a><br/>";
} elseif (isset($player["macros"]["last"]) && (mb_substr($player["macros"]["last"],0,2)=="n." || mb_substr($player["macros"]["last"],0,2)=="u.")) {
$page_main.="<a href=\"$PHP_SELF?sid=$sid&attack=".$player["macros"]["last"]."\">Повторить</a><br/>";
}
for ($i=1;$i<10;$i++) if (isset($player["macros"][$i])) {
$obj=$player["macros"][$i]["obj"];
$page_main.="<a href=\"$PHP_SELF?sid=$sid&use=".$obj."\">".$player["macros"][$i]["name"]."</a><br/>";
}
$page_main.="<a href=\"$PHP_SELF?sid=$sid&menu=1\">Меню</a>";
}

/*Арена*/
if (file_exists("arena/arena.dat")) {
	$timeboy=unserialize(file_get_contents("arena/arena.dat"));
if (time()>$timeboy["time"]) {
	unlink("arena/arena.dat");
	unlink("arena/go/". $timeboy["login1"]);
	unlink("arena/go/". $timeboy["login2"]);
}
}
/*Арена*/	

$itemN=explode("|",file_get_contents("items/".$set[8]));
if ($usrOn) {
$page_main.="</p></card><card id=\"user\" title=\"Меню\"><p>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&speak=$(to)\">Говорить</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&attack=$(to)\"> <img src=\"atack.png\"/> Атаковать</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&list=items&to=$(to)\">Предмет</a><br/>";
if (isset($player["items"]["i.snowball"])) {$page_main.="<a href=\"$PHP_SELF?sid=$sid&use=i.snowball&to=$(to)\">Кинуть снежок</a><br/>";}
if ($set[9]) {
$page_main.="[<a href=\"$PHP_SELF?sid=$sid&list=prof&id=healer&do=1&to=$(to)\">Лечить бинтами</a>]<br/>";
$page_main.="[<a href=\"$PHP_SELF?sid=$sid&list=prof&id=healer&do=2&to=$(to)\">Воскресить</a>]<br/>";
$page_main.="[<a href=\"$PHP_SELF?sid=$sid&list=prof&id=stealer&to=$(to)\">Своровать</a>]<br/>";
}
if ($player["abillity"]["grom"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.grom&to=$(to)\">Удар Грома</a><br/>";
if ($player["abillity"]["mana_res"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.mana&to=$(to)\">Восстановление Маны</a><br/>";
if ($player["abillity"]["fire_rain"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.fire_rain\">Огненный Дождь</a><br/>";
if ($player["abillity"]["sky"]) $page_main.="[<a href=\"$PHP_SELF?sid=$sid&use=a.sky\">Небесная Стрела</a>]<br/>";
if ($set[8] && $itemN[0]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=".$set[8]."&to=$(to)\">".$itemN[0]."</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&transfer=1&to=$(to)\">Передать</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&obmen=$(to)\">Обмен</a><br/>";
$page_main.="<anchor>Инфо<go href=\"$PHP_SELF?sid=$sid\" method=\"post\">
<postfield name=\"lookTo\" value=\"$(to)\" type=\"hidden\"/>
</go></anchor><br/>";
if ($player["gr_inv"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&group=enter&to=$(to)\">Вступить</a><br/>";
if ($player["group"]["leader"]==$login) $page_main.="<a href=\"$PHP_SELF?sid=$sid&group=add&to=$(to)\">В группу</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&ignor=add&to=$(to)\">* В игнор</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&contact=add&id=$(to)\">* В контакты</a>";
}
if ($npcOn) {
$page_main.="</p></card><card id=\"npc\" title=\"Меню\"><p>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&speak=$(to)\">Говорить</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&attack=$(to)\"><img src=\"atack.png\"/> Атаковать</a><br/>";
$page_main.="<a href=\"$PHP_SELF?sid=$sid&to=$(to)&list=items\">Предмет</a><br/>";
if ($player["abillity"]["grom"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.grom&to=$(to)\">Удар Грома</a><br/>";
if ($player["abillity"]["mana_res"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.mana&to=$(to)\">Восстановление Маны</a><br/>";
if ($player["abillity"]["fire_rain"]) $page_main.="<a href=\"$PHP_SELF?sid=$sid&use=a.fire_rain\">Огненный Дождь</a><br/>";
if ($player["abillity"]["sky"]) $page_main.="[<a href=\"$PHP_SELF?sid=$sid&use=a.sky\">Небесная Стрела</a>]<br/>";
if ($set[8] && $itemN[0]) $page_main.="[<a href=\"$PHP_SELF?sid=$sid&use=".$set[8]."&to=$(to)\">".$itemN[0]."</a>]<br/>";
$page_main.="<anchor><b>Инфо</b><go href=\"$PHP_SELF?sid=$sid\" method=\"post\">
<postfield name=\"lookTo\" value=\"$(to)\" type=\"hidden\"/>
</go></anchor><br/>";
}
msg($page_main,$game_title."(".$loc[0].")",1,'main');
?>