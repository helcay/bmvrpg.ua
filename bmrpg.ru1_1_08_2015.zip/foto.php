<?php
error_reporting(0);
header("Content-type:text/html;charset=utf-8");
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">';
echo "<html><head><title>Р РЎР µРЎР‘Р єР ѕР ЅР µРЎР—Р ЅРЎР›Р в„– Р Р¬Р С‘РЎРђ</title></head><body>";
$login=$_POST["login"];
$pass=$_POST["pass"];
if (!$_SERVER["QUERY_STRING"]) {
echo "Р Р§Р шР іРЎРђРЎР“Р ·Р єР ш РЎР”Р ѕРЎР’Р ѕ<br/>
---<br/>
<form action=\"foto.php?enter\" method=\"post\" enctype=\"multipart/form-data\">
<b>Р Р«Р ѕР іР С‘Р Ѕ:</b><br>
<input name=\"login\"><br> 
<b>Р РЇР шРЎРђР ѕР »РЎРњ:</b><br>
<input name=\"pass\" type=\"password\"><br>
<b>Р РґР ѕРЎР’Р ѕ:</b><br>
<input type=\"file\" name=\"filename\"><br>
<input type=\"submit\" value=\"Р Р§Р шР іРЎРђРЎР“Р ·Р С‘РЎР’РЎРњ\"><br>
</form>
---<br/>
<a href=\"game.php\">Р Р­Р ш Р іР »Р шР ІР ЅРЎР“РЎРћ</a>";
} elseif ($login && $pass && $_SERVER["QUERY_STRING"]=="enter") {
$login="u.".$login;
if (!file_exists("users/".$login.".dat")) {
echo "Р РІР шР єР ѕР іР ѕ Р »Р ѕР іР С‘Р ЅР ш Р ЅР µ РЎР‘РЎР“РЎР™Р µРЎР‘РЎР’Р ІРЎР“Р µРЎР’";
echo "</body></html>";
exit;
} else {
$check=file_get_contents("users/".$login.".dat");
$player=unserialize($check);
$info=explode("|", $player["info"]);
if ($_POST["pass"]!=$info[0]) {
echo "Р Р­Р µР ІР µРЎРђР ЅРЎР›Р в„– Р їР шРЎРђР ѕР »РЎРњ";
echo "</body></html>";
exit;
}
}
if ($_FILES["filename"]) {
if ($_FILES["filename"]["size"]>1024*64) {
echo "Р Р°Р шР ·Р јР µРЎРђ РЎР”Р ѕРЎР’Р ѕ Р їРЎРђР С‘Р ІРЎР›РЎРР шР µРЎР’ Р ЅР ѕРЎРђР јРЎР“: 64 Р єР РЎ";
echo "</body></html>";
exit;
}
if ($_FILES["filename"]["type"]!="image/jpeg"){
echo "Р Р¤Р »РЎРџ Р ·Р шР іРЎРђРЎР“Р ·Р єР С‘ Р ґР ѕРЎР‘РЎР’РЎР“Р їР ЅРЎР› РЎР’Р ѕР »РЎРњР єР ѕ .jpg РЎР”Р ѕРЎР’Р ѕ";
echo "</body></html>";
exit;
}
unlink("foto/".$login.".jpg");
if (copy($_FILES["filename"]["tmp_name"],"foto/".$login.".jpg")) {
echo "Р РґР ѕРЎР’Р ѕ Р ·Р шР іРЎРђРЎР“Р ¶Р µР ЅР ш!<br>";
$open=file_get_contents("foto/".$login.".jpg");
$open=str_replace("<?", "", $open);
$open=str_replace("?>", "", $open);
unlink("foto/".$login.".jpg");
$save=fopen("foto/".$login.".jpg", "w+");
fputs($save, $open);
fclose($save);
} else echo "Р Р®РЎРР С‘Р ±Р єР ш Р ·Р шР іРЎРђРЎР“Р ·Р єР С‘ РЎР”Р ѕРЎР’Р ѕ";
} 
} else echo "Р Р®РЎРР С‘Р ±Р єР ш Р ІРЎР•Р ѕР ґР ш";
echo "</body></html>";
?>