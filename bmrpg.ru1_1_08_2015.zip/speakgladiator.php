<?php
/*Гладиатор*/
if (!$arena) {
	$stmp="Давай сейчас оставим заявку на бой<br/>---<br/>";
	$stmp.="<u>Сколько репутации ставишь:</u><br/>
<input name=\"repa\" maxlength=\"15\"/><br/>
<u>Время боя:</u><br/>
<select name=\"val\">
<option value=\"60\">1 минута</option>
<option value=\"180\">3 минуты</option>
<option value=\"300\">5 минут</option>
</select><br/>
<anchor>Оставить заявку<go href=\"$PHP_SELF?sid=$sid&speak=$speak&id=$id&arena=ok\" method=\"post\">
  <postfield name=\"repa\" value=\"$(repa)\" />
  <postfield name=\"val\" value=\"$(val)\" />
  </go> </anchor>
<br/>---<br/>";
$stmp.="<br/><a href=\"$PHP_SELF?sid=$sid\">В игру</a>";	
} elseif ($arena=='ok') {
	if (!intval($_POST['repa'])) {msg('Не верный формат репутации!');}
	if (!intval($_POST['val'])) {msg('Не верный формат времени!');}
	$repa=intval($_POST['repa']);
	$val=intval($_POST['val']);
	if ($repa < 0) {msg('Не верное значение поля репутация! Минимум 1 репутация!');}
    if ($player['reput']<$repa) {msg('У вас не достаточно репутации!');}
    if (file_exists("arena/".$login)) {msg("Для создания новой завки вам необходимо удалить старую!");}
	$zayaav=check_var($login);
	$zayaavCheck=array(
"login"=>$player['title'],
"repa"=>$repa,
"time"=>$val,
);
$f=fopen("arena/".$login, "w+");
chmod($f, 0666);
fputs($f, serialize($zayaavCheck));
fclose($f);
if ($val == 60) {$vremya = "1 минуту";}
if ($val == 180) {$vremya = "3 минуты";}
if ($val == 300) {$vremya = "5 минут";}
	$stmp="Заявка на ". $repa ." репутации на время ". $vremya ." успешно создана";
        $stmp.="<br/><a href=\"$PHP_SELF?sid=$sid\">В игру</a>";
}
msg($stmp);
?>